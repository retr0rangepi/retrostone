#!/bin/bash

source /home/pi/RetrOrangePi/GPIO/config/config_tz_gpio.sh
source /home/pi/RetrOrangePi/GPIO/install_base.sh
