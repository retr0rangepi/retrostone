#!/bin/bash

source /home/pi/RetrOrangePi/GPIO/config/config_nes.sh
source /home/pi/RetrOrangePi/GPIO/install_base.sh
