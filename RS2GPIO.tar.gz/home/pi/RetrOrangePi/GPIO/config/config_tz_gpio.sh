#!/bin/bash

driver_name="tz_gpio_controller"
welcome_message="RetrOrangePi GPIO installer brought you by TZ GAMES SP"
