#!/bin/bash

driver_name="nes_controller"
welcome_message="NES CONTROLLER INSTALLER"
